int main()
{
	int a,b,c[10];
	char c,d;
	a=10;
	c=a*b;
	d=a+c*b;
}$