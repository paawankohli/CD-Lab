main()
{
	int a;
	a=20;
	if(a==20){
		a=10;
	}
	else{
		a=30;
	}
	while(a!=50)
	{
		a=a+1;
	}
}$