#include <stdio.h>
aaa
#include
printf("#");
return 0;
