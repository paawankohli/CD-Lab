int main()
{
	//hello
	for(i=0;i<10;i=i+1);
}$